import requests

url = "https://ngw.devices.sberbank.ru:9443/api/v2/oauth"

payload = 'scope=GIGACHAT_API_CORP'
headers = {
  'RqUID': '6f0b1291-c7f3-43c6-bb2e-9f3efb2dc98e',
  'Content-Type': 'application/x-www-form-urlencoded',
  'Authorization': 'Basic MDNlY2Y0OWEtMTJmZS00Y2M5LThjNjgtZGIwODk4ZDVlY2NhOjkzZjBlM2VhLWRlMWYtNDc2Ny1hN2Y4LTNjZmJkODFiMWE4Mg=='
}

response = requests.request("POST", url, headers=headers, data=payload)
response = response.json()
print(response['access_token'])