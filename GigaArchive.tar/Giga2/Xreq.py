"""Пример перенаправления заголовков запроса в GigaChat"""
import gigachat.context
from gigachat import GigaChat

ACCESS_TOKEN = 'eyJjdHkiOiJqd3QiLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIiwiYWxnIjoiUlNBLU9BRVAtMjU2In0.PqDwbDB2HqCpnZCQxfnFJlOFDOZ4AQ3HT-FpKJsjni8ZYp979zCth_B_76aYLpMvDbPO8SkZHqTJ-xnGUeiTv1sZ3YShZkapH0sb1YfVI32ifhzQpoNtC77M73YP6BcC4GOKaEet3Q6oJFGrhCTiZ1iz3IRbi2_dFscnWp96emWdoTlDwZU5iNttewalB1CgS7s4XVrMTawcTzFG4XKF4SV-ON-jWmg8ItCPj2xn4NOB1bjhXnzRF4OBP97RUS_m7pQANymQJrlIsk9E3_xhhBoyLZiV17K-FQdugXVYH_GTdAttvdflksS296HaNlF3Ds-k9M4f01hr7AL89-ybig.OyFh6fulJl5U6NZoq4Y44Q.nL0VDVAFrHkCZPygkosjirgRWsq851yembNsqY7znmrhHAVGF47jevo0Km5X4uOwsosTuIX4XuhJ6sMSeD1YXZ4GxiuichJuMkpf_km-YuAezZ1HjqsjET26kELpdeUYtndb6TghyQhdI506oqMu-VE4pKIIiKNiYDg8Wz87LtfLHJxmq1keuZjWDSK2R8zCyXHWOF7FJjJc7bTeL4QSVPqmiBOVaujPFRY7EbTAki4MXZMoi1NDvb05AiI_vsN8UO5tsRMBPfJTZKf4WEqlIiH_n-Tk_Y0b0fDHlbUSeuA5-GaKfseRPftenHk5CPnDoy3UBSAbU39aVq1-4M0XHHK7pDzFWApgR8rpIb2E2dvU__sEBZdE87sHN4JkLwvE8XvjcCJlJtEarVoNhT7ObN6NCdP0l4Fn6kvFTmGl_Zv0s41fcJyDUz3_vT0sogzmOVuIWIsC3QMzOesajMXrYlN2SGlho4-ArUjWV5izVc4U57dCcU4C76WO1qNTLisGKZMB7W9BGxj32q0yBTFBTlRbWzNaEBZKQoFhVuHMETMc67NOBqLnn5PMAS_8QJJOzfI7UovP7HYCnKfy6M7E1R1MtC0SvgR2dZzORl1edESyPDC3rXcfZGf0IOJjuJspuH64L6VIiBOAwEmS6FORum4JCcq8MkPlVYPUB0PDZvc7jcCWIMJWpI9-bwPOATZnXR3tB9y6h-ZOR73WdYLvZgNK-gEpdK8Kg5hxFztmXC0.lRO6cRMvv2Ay-OsYNBE--v8bF7TtGhoAncx_rbHOlsg'

headers = {
    "Authorization": f"Bearer {ACCESS_TOKEN}",
    # for logging
    "X-Session-ID": "b6874da0-bf06-410b-a150-fd5f9164a0b2",
    "X-Request-ID": "79e41a5f-f180-4c7a-b2d9-393086ae20a1",
    "X-Service-ID": "my_custom_service",
    "X-Operation-ID": "my_custom_qna",
}

with GigaChat(verify_ssl_certs=False) as giga:
    gigachat.context.authorization_cvar.set(headers.get("Authorization"))
    gigachat.context.session_id_cvar.set(headers.get("X-Session-ID"))
    gigachat.context.request_id_cvar.set(headers.get("X-Request-ID"))
    gigachat.context.service_id_cvar.set(headers.get("X-Service-ID"))
    gigachat.context.operation_id_cvar.set(headers.get("X-Operation-ID"))

    response = giga.chat("Какие факторы влияют на стоимость страховки на дом?")
    print(response.choices[0].message.content)