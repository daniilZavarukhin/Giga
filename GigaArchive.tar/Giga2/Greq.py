import streamlit as st
from langchain.llms import OpenAI

import requests
import json
import linecache

URL = "https://gigachat.devices.sberbank.ru/api/v1/chat/completions"

TOKEN = linecache.getline('/home/pupsik/Giga/llm-examples/token.txt', 1).strip().replace('"', '')

headers = {
'Content-Type': 'application/json',
'Accept': 'application/json',
'Authorization': f'Bearer {TOKEN}'
}

print(headers)