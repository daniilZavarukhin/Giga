
import requests
import json

url = "https://gigachat.devices.sberbank.ru/api/v1/chat/completions"

payload = json.dumps({
  "model": "GigaChat",
  "messages": [
    {
      "role": "system",
      "content": "Ты профессиональный переводчик на английский язык. Переведи точно сообщение пользователя."
    },
    {
      "role": "user",
      "content": "GigaChat — это сервис, который умеет взаимодействовать с пользователем в формате диалога, писать код, создавать тексты и картинки по запросу пользователя."
    }
  ],
  "n": 1,
  "stream": False,
  "update_interval": 0
})
headers = {
  'Content-Type': 'application/json',
  'Accept': 'application/json',
  'Authorization': 'Bearer eyJjdHkiOiJqd3QiLCJlbmMiOiJBMjU2Q0JDLUhTNTEyIiwiYWxnIjoiUlNBLU9BRVAtMjU2In0.rp3dYObIz51BnaKbyLEX4i5gIhjSsszGdFMLRtBO1R75hFr15UH8_6warS9haNk5cxcFn-1XZ5KPZIeKDWQiiP0XmRCk1KucUsiofP66fgZODx2xkB1hufVU6we5hisQXv6u6c2coQ3C_YsViz74bexVrPxW8LTgYFYCVNFK_AU63LAd7KJF4jmZVQwgQbxOUT6uUXZKSFCWsGKsVaqm-Agzw9pfshuWAgMV5lpBv2o6noQO5OwV9VkR7PNvK0bxxrv6GfYVOyPAeNwM7OOjT537x08YUA0Ph2iLYSZ7MyOKT7vADbFDzMuc5mrtQHk_1bQJxZIsIc5_ft8QKxjQwQ.zNkZIjuV62n9lo3Bo9tNTg.BYnpzf1PUZPo9XIWwMqMPR8usvz27WTJsmV-C12w84OamaPlf3ezhp1105brrSYc5zVh10DQOLk_5wFrfvdIJYgZqXR3togykAOmROMEOl62juZaqzOcr9-XwHNKqFpyJf4KHw1qemAw273v5Cldrt69a4sdGKwra26v6HqoNw7US1T9Vist6uwooBOyRXBvLi5ExYPNFseqqs_gFpPEoJAIo9SbMRiQV10RIYj_dJd-XC5HEJc_fpZxl5fdInk4MIwSADhA-zRydlX9SE1Coz9GyNsI-NJhd0fSu4Itj2PQH3Fz8tgi0a_QQ13lb7Re33uKdGslZ0HArnN0b8MO3_nd4G5RGIOkXVZkY6EsRw6mns5Ysjb1Dz3M7IuVOylotz_h6PiynO2AZekdOzLHY2au8S-LxDTqqLwtcy8cVM9vNH9LuFYp0Q0LVmH_8qFh_px1lo5_jV5ymRNd426hRhwXxXIImN5SSOdV1QFX0UPyUjX_q1LIuoG5rMbYH8be8_Z--lMYMP1mH6yNoKje1qa1vGDrioCZJ75i68ZLd1i6xFj1YICV8UgPk67cO5PC6Kl8X0E2uPZo6FXvOQ2_cHPc8nYbUMekTJxnqzqiYvJsEVIKh_YyVzxdk08QyHb2jI0FX167So9FzYUk8AwTevkP96XyaJBthrrlxNzo7T3LPG81NpULndhLEj_Liq2IdX7mVhijdWjbQIYdvaCvW_li_p-m3QShKBfBAD8DTPU.q-gm648vs1EzgvkKK1qjTZmuHDjT3-jdOjhNqvF1SHA'
}

response = requests.request("POST", url, headers=headers, data=payload)
response = response.json()
print(response['choices'][0]['message']['content'])