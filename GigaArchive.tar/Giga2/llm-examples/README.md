## Run it locally
1. Поставить задачу в крон таску 
*/15 * * * * ./maketoken.sh

2. Создать таблицу в базе
CREATE TABLE requesttogiga ( date timestamp,model text,role text,task text,answer text);

3. Прописать креды для подключения 
./.streamlit/secrets.toml

4.
```sh
virtualenv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run GigaChat.py 
```
