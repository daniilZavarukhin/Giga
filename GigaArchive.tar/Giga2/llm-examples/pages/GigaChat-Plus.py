import streamlit as st
import requests
import json
import linecache
from sqlalchemy import text
#from langchain.llms import OpenAI
from datetime import datetime


URL = "https://gigachat.devices.sberbank.ru/api/v1/chat/completions"
MODEL = "GigaChat-Plus"

def generate_response(model,role,task):
    # make token
    TOKEN = linecache.getline('../../token.txt', 1).strip().replace('"', '')
    # cred for request and request
    payload = json.dumps({
            "model": f"{model}",
            "messages": [
                {
                "role": "system",
                "content": f"{role}"
                },
                {
                "role": "user",
                "content": f"{task}"
                }
            ],
            "n": 1,
            "stream": False,
            "update_interval": 0
    })
    headers = {
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'Authorization': f'Bearer {TOKEN}'
    }
    response = requests.request("POST", URL, headers=headers, data=payload)
    response = response.json()
    # print answer
    st.info(response['choices'][0]['message']['content']) 
    # write log to postgresql
    now = datetime.now()
    conn = st.connection("postgresql", type="sql")
    with conn.session as session:
        session.execute(text("INSERT INTO requesttogiga VALUES (:date,:model,:role,:task,:answer);"), 
                            {"date": now.strftime("%Y-%m-%d %H:%M:%S"), "model": model,"role": role,"task": task,"answer": response['choices'][0]['message']['content']})
        session.commit()
        
        
st.set_page_config(page_title="ALL GigaChat",layout="wide")
st.title(f"{MODEL}")
with st.form('my_form'):
    ROLE = st.text_area('Введите роль:', 'Губернатор Волгоградской области')
    TASK = st.text_area('Введите задание:', 'Придумай крутой законопроект')
    if st.form_submit_button('Отправить'):
        generate_response(MODEL,ROLE,TASK)