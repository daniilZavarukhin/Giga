ГПН: GigaCube

REST API

Запросить токен доступа для работы с GigaChat API: 
curl -X POST -u <login>:<password> --basic "https://gigachat.techpark.local/v1/token"

Список доступных моделей: 
curl --request GET \
 --url https://gigachat.techpark.loca/v1/models \
 --header 'Authorization: Bearer <TOKEN>'

Запрос в GigaChat API с использованием полученного токена: 
curl -X POST \
 --url https://gigachat.techpark.loca/v1/chat/completions \
 --header 'Authorization: Bearer <TOKEN>' \
 --header 'Content-Type: application/json' \
 --data '{
 "model": "GigaChat-29b-8k-base:2.2.25.3",
 "messages": [
 {
 "role": "user",
 "content": " ?"
 },
 {
 "role": "user",
 "content": "How much is a fish?"
 }
 ]
}'

Учётные записи


login: "user",
password": "password"

Мониторинг

Адрес: http://monitoring.gigachat.techpark.local:3000 

Dashboards:
•	NGINX - официальный Dashboards для мониторинга nginx
•	Node Exporter Fill - подробный мониторинг основных параметров серверов. CPU/Mem/Disk
•	NVIDIA DCGM Exporter Dashboard - информация о GPU
•	WMcore - метрики сервиса, который отвечает за GigaChat. В данном Dashboards стоит обратить снимание на график "WMcore (очередь запросов)". Если график растет, то есть вероятность что WMcore не успевает обрабатывать поступающие запросы, поэтому на front могут быть ошибки "500"
